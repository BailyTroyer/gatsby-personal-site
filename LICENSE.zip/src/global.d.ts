declare module '*.scss';
declare module '*.css';
declare module '*.svg';
declare module '*.png';
declare module '*.jpg';
